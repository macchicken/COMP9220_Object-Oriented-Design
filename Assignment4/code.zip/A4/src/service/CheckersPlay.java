package service;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Common.Constants;
import model.Board;
import model.Coordinate;

public class CheckersPlay implements IPlay{

	private char p1;
	private char p2;
	private char playerCurrent;
	private Scanner keyboard = new Scanner(System.in);
	private int stepCount;  //start from 0
	private int maxRedoTimes;
	private Time t = new Time(60);
	private List<Command> cmds = new ArrayList<Command>();
	private Board bg = Board.getInstance();
	private CheckRule check;
	private Coordinate coordinate, previous;
	
    public CheckersPlay(char p1, char p2 ,CheckRule check){
    	super();
		this.p1 = p1;
		this.p2 = p2;
		this.playerCurrent = p1;
		this.check = new CheckersCheck(null);
		System.out.println("This is Checkers.");
		System.out.println("Game initialization done.");
		bg.initialCheckers(Constants.LENGTH_X, Constants.LENGTH_Y);
		displayBoard();
	}
	
	public void switchPlayer() {
		switch(stepCount%2){
			case 0:  
				playerCurrent = p1; 
				break;
			case 1:  
				playerCurrent = p2; 
				break;
		}
	}
	
	public void displayBoard() {
		System.out.println("Game board:");
		bg.displayBoard();
	}

	public void play() {
		
		do{
			this.switchPlayer();
			
			System.out.println("Now is the chance of " + playerCurrent);
			System.out.println("This is No." + (stepCount+1) + " step.");
			System.out.println("You have 60 seconds to think and input.");
			t.start();
			do{
				System.out.println("Please input the coordinate of the disk you want to move, in this format: x,y");
				System.out.println("x & y are integers between 0 and 7.");
			}while(!input());
			//currentStep.setStepC1(coordinate);
			
			do{
				System.out.println("Please input the coordinate to move the disk to, in this format: x,y");
				System.out.println("x & y are integers between 0 and 7.");
			}while(!input());
			
			displayBoard();

			if(this.getP2Num()==0){
				System.out.println("The winer is X (Black).");
				break;
			}
			else if(this.getP1Num()==0){
				System.out.println("The winer is O (White).");
				break;
			}
			else{
				this.reconsider();
				continue;
			}

		}while(true);
		
		stepCount++;
		
	}
	
	public boolean input(){
		String input = "";
		input = keyboard.nextLine();
		Command cmd=null;
		if(playerCurrent=='x'){
			cmd=new BlackCommand(previous,coordinate);
		}else{
			cmd=new WhiteCommand(previous,coordinate);
		}
		try{
			coordinate = new Coordinate(input);
			if(((CheckersCheck) check).inBoard(coordinate)){
				cmds.add(cmd);
				return true;
			}
			else{
				return false;
			}
		}
		catch (Exception e){
			System.out.println("Input error: wrong format. Input again please.");
			System.out.println();
			return false;
		}
	}

	/**This part is UNDO & REDO*/
	public void reconsider() {
		String input = "";
		int I = 0;
		System.out.println("How many steps do you want to undo?");
		System.out.println("If you do not want to undo, input any integer no bigger than 0.");
		System.out.println("Max undo times: " + stepCount);
		input = keyboard.nextLine();
		
		try{
			I = Integer.parseInt(input);
		}catch (Exception e){
			System.out.println("Input error, please input an integer.");
			this.reconsider();
		}
		if(I<=0){
			System.out.println("Undo cancel. Switch to the next player...");
			System.out.println();
		}
		else if(0<I && I<=stepCount){
			maxRedoTimes = I;
			System.out.println("Undo " + I + " times.");
			undoSteps(I);
			displayBoard();
			reReconsider();
		}
		else{
			maxRedoTimes = stepCount;
			System.out.println("Exceeds the stepCount, it will undo all the steps.");
			undoSteps(stepCount);
			displayBoard();
			reReconsider();
		}
	}

	public void undoSteps(int n){
		for(int i=0; i<n; i++){
			stepCount--;
			//currentStep.setStep(steps[stepCount].getStepC2(), steps[stepCount].getStepC1());
			//bg.setBoard(currentStep);
		}
	}

	public void reReconsider() {
		String input = "";
		int I = 0;
		System.out.println("How many steps do you want to redo?");
		System.out.println("If you do not want to redo, input any integer no bigger than 0.");
		System.out.println("Max redo times: " + maxRedoTimes);
		input = keyboard.nextLine();
		try{
			I = Integer.parseInt(input);
		}catch (Exception e){
			System.out.println("Input error, please input an integer.");
			this.reReconsider();
		}
		if(I == 0){
			System.out.println("Redo cancel. Switch to the next player...");
			System.out.println("");
		}
		if(0<I && I<=maxRedoTimes){
			System.out.println("Redo " + I + " times.");
			redoSteps(I);
			displayBoard();
		}
		else{
			System.out.println("Exceeds the max redo steps, it will redo all the steps.");
			redoSteps(maxRedoTimes);
			displayBoard();
		}
		
	}
	
	public void redoSteps(int n){
		for(int i=0; i<n; i++){
			//currentStep.setStep(steps[stepCount].getStepC2(), steps[stepCount].getStepC1());
			//bg.setBoard(currentStep);
			stepCount++;
		}
	}
	/**End of UNDO & REDO*/

	public int getP1Num(){
		int p1Disks = 0;
		for(int i=0; i<Constants.LENGTH_X; i++){
			for(int j=0; j<Constants.LENGTH_Y; j++){
				if(bg.getChar(i,j) == p1){
					p1Disks++;
				}
			}
		}
		return p1Disks;
	}
	
	public int getP2Num(){
		int p2Disks = 0;
		for(int i=0; i<Constants.LENGTH_X; i++){
			for(int j=0; j<Constants.LENGTH_Y; j++){
				if(bg.getChar(i,j) == p2){
					p2Disks++;
				}
			}
		}
		return p2Disks;
	}

	public void end() {
		bg.setNull();
	}

	@Override
	public boolean check() {
		// TODO Auto-generated method stub
		return false;
	}
}
