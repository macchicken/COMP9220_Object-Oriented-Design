package service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import Common.Constants;
import model.Board;
import model.Coordinate;

public class GomokuPlay implements IPlay {

	private char play1;
	private char play2;
	private char playCurrent;
	private InputStreamReader isr;
	private BufferedReader br;
	private CheckRule<HashMap<String, Object>,String> check;
	private int count;
	private Time t;
	private List<Command> cmds=new ArrayList<Command>();
	private Coordinate previous=new Coordinate(0,0);
	private Board bg = Board.getInstance();
	
	public GomokuPlay(char play1, char play2,int lenX,int lenY,CheckRule<HashMap<String, Object>, String> check,int maxTime) {
		super();
		this.play1 = play1;
		this.play2 = play2;
		this.playCurrent=play1;
		this.isr = new InputStreamReader(System.in);
		this.br = new BufferedReader(isr);
		this.bg.initialGomoku(lenX, lenY);
		this.count=0;
		this.check=check;
		this.t=new Time(maxTime);
	}

	
	@Override
	public void play() {
		this.bg.displayBoard();
		inputCoordinate();
	}
	
	private void inputCoordinate(){
		String input=null;
		String player=Constants.getDiskName(this.playCurrent);
		System.out.println(player+"'s turn: Where do you wish to place your disc?\nPlease type x and y locations :");
		try {
			t.start();
			while ((input=this.br.readLine())!=null){
				input=input.trim();
				if(!t.isTimeOut()){
				if ("".equals(input)){continue;}
				if (!Constants.numPair.matcher(input).matches()){
					System.out.println("type a location in a format of x,y");
					continue;
				}
				String[] location=input.split(",");
				Coordinate coordinate=new Coordinate(Integer.parseInt(location[0].trim()),Integer.parseInt(location[1].trim()));
				boolean valid=this.bg.validPosition(coordinate);
				if (!valid){continue;}
					this.count++;Command cmd=null;
					if(player=="Black"){
						cmd=new BlackCommand(previous,coordinate);
					}else{
						cmd=new WhiteCommand(previous,coordinate);
					}
					cmd.execute(bg);
					cmds.add(cmd);
					previous=coordinate;
					System.out.println("You have placed "+ player+" disc at "+coordinate);
				}else{
					System.out.println("Time is out! Change player");
				}
				break;
			}
		} catch (IOException e) {
			System.out.println("ioe"+e.getMessage());
			e.printStackTrace();
		}
	}

	private void switchPlayer(){
		if (this.playCurrent==this.play1){this.playCurrent=this.play2;}
		else{this.playCurrent=this.play1;}
	}

	public boolean check(){
		HashMap<String,Object> checkObjs=new HashMap<String,Object>();
		checkObjs.put("currentPlayer", this.playCurrent);
		checkObjs.put("matrix", bg.getBoard());
		checkObjs.put("count", count);
		boolean result=this.check.check(checkObjs);
		if (!result){switchPlayer();return true;}
		return false;
	}

	@Override
	public void end() {
		try {
			this.br.close();this.isr.close();
			System.out.println(this.check.getCheckResult());
			this.bg.displayBoard();
		} catch (IOException e) {
			System.out.println("ioe "+e.getMessage());
		}
	}

	private void redo(String player,int steps){
		if (cmds.isEmpty()){
			System.out.println("You did not put any disk yet!");
		}else{
			int total=steps+this.count;
			if (total>cmds.size()){
				System.out.println("You excess the available steps!");
			}else{
				for (int i=this.count;i<total;i++){
					cmds.get(i).execute(bg);
				}
				this.count+=steps;
			}
		}
	}

	private void undo(String player,int steps){
		if (cmds.isEmpty()){
			System.out.println("You did not put any disk yet!");
		}else{
			if ((this.count-steps)<0){
				System.out.println("You excess the available steps!");
			}else{
				int start=cmds.size()-steps;
				for (int i=start;i<cmds.size();i++){
					cmds.get(i).undo(bg);
				}
				this.count-=steps;
			}
		}
	}


}
