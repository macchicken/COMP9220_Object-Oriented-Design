package service;

import Common.Constants;
import model.Board;
import model.Coordinate;

public class CheckersCheck extends CheckRule{

	public CheckersCheck(String checkResult) {
		super(checkResult);
		// TODO Auto-generated constructor stub
	}

	private Board bg = Board.getInstance();
	
	public boolean inBoard(Coordinate cood) {
		int x = cood.getX();
		int y = cood.getY();
		if(0<=x && x<Constants.LENGTH_X && 0<=y && y<Constants.LENGTH_Y){
			return true;
		}
		else{
			System.out.println("Input error: out of board.");
			System.out.println();
			return false;
		}
	}
	
	public boolean ifExist(Coordinate cood){
		int x = cood.getX();
		int y = cood.getY();
		if(bg.getChar(x,y) == ' '){
			return true;
		}
		else{
			return false;
		}
	}
	
	public boolean samePlayer(Coordinate cood, char c){
		int x = cood.getX();
		int y = cood.getY();
		if(bg.getChar(x,y) == c){
			return true;
		}
		else{
			return false;
		}
	}

	@Override
	public boolean check(Object checkObjs) {
		// TODO Auto-generated method stub
		return false;
	}
}
