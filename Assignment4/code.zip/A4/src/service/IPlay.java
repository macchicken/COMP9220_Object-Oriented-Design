package service;

public interface IPlay {

	public void play();
	public void end();
	public boolean check();
}
