import java.util.HashMap;

import model.Board;
import Common.Constants;
import service.CheckRule;
import service.GomokuPlay;
import service.GomokuPlayCheck;
import service.IPlay;


public class GomokuGameBuilder extends ChessGameBuilder{
	
	private CheckRule<HashMap<String,Object>,String> checkRule;
	
	@Override
	public void buildGameBoard(int mode, long timeout) {
		Board.getInstance();
	}

	@Override
	public void buildGameRule() {
		checkRule=new GomokuPlayCheck(64);
	}

	@Override
	public IPlay getChessGame() {
		return new GomokuPlay(Constants.black, Constants.white, 15, 15, checkRule,10);
	}

}
