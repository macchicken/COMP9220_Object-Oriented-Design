package model;

import Common.Constants;

public class Board {

	protected static char[][] grids = null;
	
	private static Board bg = null;
	
	private Board(){}
	
	public static Board getInstance(){
		if(bg == null){
			bg = new Board();
			
		}
		return bg;
	}
	
	public void initialGomoku(int lenX, int lenY){
		grids=new char[lenX][lenY];
		for (int x=0;x<grids.length;x++){
			for (int y=0;y<grids.length;y++){
				grids[x][y]=Constants.empty;
			}
		}
	}
	
	public void initialCheckers(int a, int b){
		grids = new char[a][b];
		for(int i=0; i<Constants.LENGTH_X; i++){
			for(int j=0; j<Constants.LENGTH_Y; j++){
				if( ((i==0||i==2) && (j==1||j==3||j==5||j==7)) 
						|| (i==1 && (j==0||j==2||j==4||j==6)) ){
					setBoard(i,j,'o');
				}
				else if( ((i==5||i==7) && (j==0||j==2||j==4||j==6)) 
						|| (i==6 && (j==1||j==3||j==5||j==7)) ){
					setBoard(i,j,'x');
				}
				else{
					setBoard(i,j,' ');
				}
			}
		}
	}

	public char[][] getBoard(){
		return grids;
	}
	
	public char getChar(int a, int b){
		return grids[a][b];
	}
	
	private void setBoard(int i, int j, char c){
		grids[i][j] = c;
	}
	
	public void setBoard(Coordinate coordinate,char z){
		int x=coordinate.getX();
		int y=coordinate.getY();
		grids[x-1][y-1]=z;
	}
	
	public void setNull(){
		bg = null;
	}
/*
	public void setBoard(Step s){
		grids[s.getStepC1().getX()][s.getStepC1().getY()] = ' ';
		grids[s.getStepC2().getX()][s.getStepC2().getY()] = s.getStepPlayer();
	}
	*/
	/*
	public void displayBoardCheckers(){
		System.out.println("-------------------------------------");
		System.out.println("|x\\y| 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 |");
		System.out.println("-------------------------------------");
		for(int i=0; i<Constants.LENGTH_X; i++){
			System.out.print("| " + i + " ");
			for(int j=0; j<Constants.LENGTH_Y; j++){
				System.out.print("| " + grids[i][j] + " ");
			}
			System.out.println("|");
			System.out.println("-------------------------------------");
		}
		System.out.println();
	}
	*/
	public void displayBoard(){
		for (int x=0;x<grids.length;x++){
			for (int y=0;y<grids[x].length;y++){
				System.out.print(grids[x][y]);
			}
			System.out.println();
		}
	}
	
	public boolean validPosition(Coordinate coordinate){
		int x=coordinate.getX();
		int y=coordinate.getY();
		if (x>grids.length||y>grids[x-1].length){
			System.out.println(" should place a disk within the board ");
			return false;
		}else if (grids[x-1][y-1]!=Constants.empty){
			System.out.println(" this place has been occupied,try again ");
			return false;
		}
		return true;
	}
}
