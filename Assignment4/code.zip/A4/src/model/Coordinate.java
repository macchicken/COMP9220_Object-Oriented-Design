package model;

public class Coordinate {

	private int x = 0;
	private int y = 0;
	private String[] XY = new String[2];
	
	public Coordinate(){}
	
	public Coordinate(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public Coordinate(String str){
		XY = str.split(",");
		x = Integer.parseInt(XY[0]);
		y = Integer.parseInt(XY[1]);
	}
	
	public int getX(){
		return x;
	}
	
	public int getY(){
		return y;
	}
}
