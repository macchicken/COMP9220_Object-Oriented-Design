
public class ChessGameDirector {
	public ChessGameBuilder builder;
	public ChessGameDirector(int mode, long timeout){
		
		if(mode == 1){
			builder = new GomokuGameBuilder();
			builder.buildGameBoard(mode, timeout);
		}
		else if(mode == 2){
			builder = new CheckerGameBuilder();
			builder.buildGameBoard(mode, timeout);
		}
	}
	
}
