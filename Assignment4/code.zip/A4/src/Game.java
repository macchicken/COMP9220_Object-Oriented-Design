import java.util.Scanner;

import service.CheckersCheck;
import service.CheckersPlay;
import service.GomokuPlay;
import service.GomokuPlayCheck;
import service.IPlay;
import Common.Constants;


public class Game {

	public static void main(String[] args) {
		start();	
	}
	
	
	public static void start(){
		IPlay play;
		Scanner scan = new Scanner(System.in);
		String choice = null;
		ChessGameDirector director;
		
		boolean f = false;
		
		
		while(!f){
			System.out.println("Input your choice(1 for Gomoku, 2 for Checker): ");
			choice = scan.next();
			System.out.println("Input the time limit:��");
			long limit  = scan.nextInt();
			if(choice.equals("1")){
				director = new ChessGameDirector(1, limit);
				director.builder.getChessGame().play();
//				play = new GomokuPlay(Constants.black,
//						Constants.white, 15, 15, new GomokuPlayCheck(64),10);
//				play.play();
				f = true;
			}else if(choice.equals("2")){
				director = new ChessGameDirector(2, limit);
				director.builder.getChessGame().play();
//				play = new CheckersPlay(Constants.PLAYER1, 
//						Constants.PLAYER2, Constants.LENGTH_X,Constants.LENGTH_Y, new CheckersCheck(null));
//				play.play();
				f = true;
			}else {
				System.out.println("input wrong game number");
			}
		}
		
		
	}
	
}
