import java.util.HashMap;

import model.Board;
import service.CheckRule;
import service.CheckersCheck;
import service.IPlay;
import service.CheckersPlay;
import Common.Constants;


public class CheckerGameBuilder extends ChessGameBuilder {

	private CheckRule<HashMap<String,Object>,String> checkRule;
	@Override
	public void buildGameBoard(int mode, long timeout) {
		Board.getInstance();
	}

	@Override
	public void buildGameRule() {
		checkRule = new CheckersCheck(null);
	}

	@Override
	public IPlay getChessGame() {
		// TODO Auto-generated method stub
		return new CheckersPlay(Constants.PLAYER1, Constants.PLAYER2,  checkRule);//Constants.LENGTH_X,Constants.LENGTH_Y,
	}

}
